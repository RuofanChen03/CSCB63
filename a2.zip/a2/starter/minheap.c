/*
 * Our min-heap implementation.
 *
 * Author (starter code): A. Tafliovich.
 * Author (implementation): R. Chen (Student number: 1008163719).
 */

#include "minheap.h"

#define ROOT_INDEX 1
#define NOTHING -1

/*************************************************************************
 ** Suggested helper functions
 *************************************************************************/

/* Returns True if 'maybeIdx' is a valid index in minheap 'heap', and 'heap'
 * stores an element at that index. Returns False otherwise.
 */
bool isValidIndex(MinHeap* heap, int maybeIdx){
	if(heap != NULL){
		return ((maybeIdx >= ROOT_INDEX) && (maybeIdx <= heap->size));
	}
	return false;
}

/* Returns priority of node at index 'nodeIndex' in minheap 'heap'.
 * Precondition: 'nodeIndex' is a valid index in 'heap'
 *               'heap' is non-empty
 * 				 if precondition not met returning INT_MAX
 */
int priorityAt(MinHeap* heap, int nodeIndex){
    if(isValidIndex(heap, nodeIndex)){
        return heap->arr[nodeIndex].priority;
    }
	return 2147483647;
}

/* Returns the index of the parent of a node at index 'nodeIndex' in minheap
 * 'heap', if such exists.  Returns NOTHING if there is no such parent.
 */
int parentIdx(MinHeap* heap, int nodeIndex){
	int possibleParent = NOTHING;
	if((isValidIndex(heap, nodeIndex)) && (nodeIndex > ROOT_INDEX)){
		possibleParent = (int) (nodeIndex/2.0);
	}
	return possibleParent;
}

/* Returns the index of the left child of a node at index 'nodeIndex' in
 * minheap 'heap', if such exists.  Returns NOTHING if there is no such left
 * child.
 */
int leftIdx(MinHeap* heap, int nodeIndex){
	int possibleLChild = NOTHING;
	if((isValidIndex(heap, nodeIndex)) && isValidIndex(heap, (nodeIndex*2))){
		possibleLChild = nodeIndex*2;
	}
	return possibleLChild;
}

/* Returns the index of the right child of a node at index 'nodeIndex' in
 * minheap 'heap', if such exists.  Returns NOTHING if there is no such right
 * child.
 */
int rightIdx(MinHeap* heap, int nodeIndex){
	int possibleRChild = NOTHING;
	if((isValidIndex(heap, nodeIndex)) && isValidIndex(heap, (nodeIndex*2+1))){
		possibleRChild = nodeIndex*2+1;
	}
	return possibleRChild;
}

/* Swaps contents of heap->arr[index1] and heap->arr[index2] if both 'index1'
 * and 'index2' are valid indices for minheap 'heap'. Has no effect otherwise.
 */
void swap(MinHeap* heap, int index1, int index2){
	if((isValidIndex(heap, index1)) && (isValidIndex(heap, index2)) &&
		(index1 != index2)){
		heap->indexMap[heap->arr[index1].id] = index2;
		heap->indexMap[heap->arr[index2].id] = index1;
		HeapNode temp = heap->arr[index1];
		heap->arr[index1] = heap->arr[index2];
		heap->arr[index2] = temp;
	}
	return;
}

/* Bubbles up the element newly inserted into minheap 'heap' at index
 * 'i', if 'i' is a valid index for heap. Has no effect otherwise.
 */
void bubbleUp(MinHeap* heap, int i){
	int newIndex = parentIdx(heap, i);
	if((isValidIndex(heap, i)) && (newIndex != NOTHING)){
		if (priorityAt(heap, i) < priorityAt(heap, newIndex)){
			swap(heap, newIndex, i);
			bubbleUp(heap, newIndex);
		}
	}
	return;
}

/* Bubbles down the element newly inserted into minheap 'heap' at the root,
 * if it exists. Has no effect otherwise.
 */
void bubbleDown(MinHeap* heap){
	if(heap != NULL){
		int i = ROOT_INDEX;
		int leftI = leftIdx(heap, i);
		int rightI = rightIdx(heap, i);
		while((leftI != NOTHING) || (rightI != NOTHING)){
			if((priorityAt(heap, i) > priorityAt(heap, leftI)) || 
				(priorityAt(heap, i) > priorityAt(heap, rightI))){
				if(priorityAt(heap, leftI) <= priorityAt(heap, rightI)){
					swap(heap, leftI, i);
					i = leftI;
				}
				else{
					swap(heap, rightI, i);
					i = rightI;
				}
				leftI = leftIdx(heap, i);
				rightI = rightIdx(heap, i);
			}
			else{
				return;
			}
		}
	}
	return;
}

/* Doubles the capacity of minheap 'heap'.
 */
void doubleCapacity(MinHeap* heap){
	if(heap != NULL){
		int capacity = 2*heap->capacity;
		heap->capacity = capacity;
		heap->arr = realloc(heap->arr, sizeof(HeapNode)*(capacity+ROOT_INDEX));
		heap->indexMap = realloc(heap->indexMap, 
									sizeof(HeapNode)*(capacity+ROOT_INDEX));
		if((heap->arr == NULL) || (heap->indexMap == NULL)){
			printf("Failed reallocation/capacity doubling.");
		}
		for(int i = capacity/2+1; i <= capacity; i++){
			heap->indexMap[i] = NOTHING;
		}
	}
	return;
}

/*********************************************************************
 * Required functions
 ********************************************************************/


/* Returns the node with minimum priority in minheap 'heap'.
 * Precondition: heap is non-empty
 */
HeapNode getMin(MinHeap* heap){
	return heap->arr[ROOT_INDEX];
}

/* Removes and returns the node with minimum priority in minheap 'heap'.
 * Precondition: heap is non-empty
 */
HeapNode extractMin(MinHeap* heap){
	HeapNode extracted = getMin(heap);
	swap(heap, ROOT_INDEX, heap->size);
	heap->indexMap[heap->arr[heap->size].id] = NOTHING;
	heap->size--;
	bubbleDown(heap);
	return extracted;
}

/* Inserts a new node with priority 'priority' and value 'value' into minheap
 * 'heap'. If 'heap' is full, double the capacity of 'heap' before inserting
 * the new node.
 *
 * Precondition: no inserting after any extraction due to ID implementation
 */
void insert(MinHeap* heap, int priority, void* value){
	if(heap != NULL){
		if(heap->size == heap->capacity){
			doubleCapacity(heap);
		}
		int newSize = (heap->size+1);
		heap->size = newSize;
		HeapNode *newNode = malloc(sizeof(HeapNode));
		newNode->priority = priority;
		newNode->value = value;
		newNode->id = newSize;
		heap->arr[newSize] = *newNode;
		heap->indexMap[newSize] = newSize;
		bubbleUp(heap, newSize);
		free(newNode);
	}
	return;
}

/* Sets priority of node with ID 'id' in minheap 'heap' to 'newPriority', if
 * such a node exists in 'heap' and its priority is larger than
 * 'newPriority', and returns True. Has no effect and returns False, otherwise.
 * Note: this function bubbles up the node until the heap property is restored.
 */
bool decreasePriority(MinHeap* heap, int id, int newPriority){
	if((heap != NULL) && (id <= heap->capacity)){
		int i = heap->indexMap[id];
		if((isValidIndex(heap, i)) && (priorityAt(heap, i) > newPriority)){
			heap->arr[i].priority = newPriority;
			bubbleUp(heap, i);
			return true;
		}
	}
	return false;
}

/* Returns a newly created empty minheap with initial capacity 'capacity'.
 * Precondition: capacity > 0
 */
MinHeap* newHeap(int capacity){
	if(capacity > 0){
		MinHeap *new = malloc(sizeof(MinHeap));
		new->size = 0;
		new->capacity = capacity;
		new->arr = (HeapNode *)malloc(sizeof(HeapNode)*(capacity+ROOT_INDEX));
		new->indexMap = (int *)malloc(sizeof(int)*(capacity+ROOT_INDEX));
		if((new == NULL) || (new->arr == NULL) || (new->indexMap == NULL)){
			printf("Failed allocation creating heap.");
		}
		for(int i = ROOT_INDEX; i <= capacity; i++){
			new->indexMap[i] = NOTHING;
		}
		return new;
	}
	return NULL;
}

/* Frees all memory allocated for minheap 'heap'.
 */
void deleteHeap(MinHeap* heap){
	free(heap->arr);
	free(heap->indexMap);
	free(heap);
}







/*********************************************************************
 ** Helper function provided in the starter code
 *********************************************************************/

/* Prints the contents of this heap, including size, capacity, full index
 * map, and, for each non-empty element of the heap array, that node's ID and
 * priority. */
void printHeap(MinHeap* heap) {
  printf("MinHip with size: %d\n\tcapacity: %d\n\n", heap->size,
         heap->capacity);
  printf("index: priority [ID]\t ID: index\n");
  for (int i = ROOT_INDEX; i <= heap->size; i++)
    printf("%d: %d [%d]\t\t%d: %d\n", i, heap->arr[i].priority, heap->arr[i].id,
           i, heap->indexMap[i]);
  for (int i = heap->size + 1; i <= heap->capacity; i++)
    printf("\t\t\t%d: %d\n", i, heap->indexMap[i]);
  printf("\n\n");
}

/*********************************************************************
 ** Helper functions not provided in the starter code
 *********************************************************************/