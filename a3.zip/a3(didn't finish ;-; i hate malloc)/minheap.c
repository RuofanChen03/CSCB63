/*
 * Our min-heap implementation.
 *
 * Author (starter code): A. Tafliovich.
 * Author (implementation): R. Chen (Student number: 1008163719).
 */

#include "minheap.h"

#define ROOT_INDEX 1
#define NOTHING -1
#define MAX_PRIORITY 2147483647

/*************************************************************************
 ** Suggested helper functions to help with your program design
 *************************************************************************/

/* Returns True if 'maybeIdx' is a valid index in minheap 'heap', and 'heap'
 * stores an element at that index. Returns False otherwise.
 */
bool isValidIndex(MinHeap* heap, int maybeIdx){
	if(heap != NULL){
		return ((maybeIdx >= ROOT_INDEX) && (maybeIdx <= heap->size));
	}
	return false;
}

/* Returns priority of node at index 'nodeIndex' in minheap 'heap'.
 * Precondition: 'nodeIndex' is a valid index in 'heap'
 *               'heap' is non-empty
 * 				 if precondition not met returning INT_MAX
 */
int priorityAt(MinHeap* heap, int nodeIndex){
    if(isValidIndex(heap, nodeIndex)){
        return heap->arr[nodeIndex].priority;
    }
	return MAX_PRIORITY;
}

/* Returns node at index 'nodeIndex' in minheap 'heap'.
 * Precondition: 'nodeIndex' is a valid index in 'heap'
 *               'heap' is non-empty
 */
HeapNode nodeAt(MinHeap* heap, int nodeIndex){
	return heap->arr[nodeIndex];
}

/* Returns ID of node at index 'nodeIndex' in minheap 'heap'.
 * Precondition: 'nodeIndex' is a valid index in 'heap'
 *               'heap' is non-empty
 */
int idAt(MinHeap* heap, int nodeIndex){
	return heap->arr[nodeIndex].id;
}

/* Returns index of node with ID 'id' in minheap 'heap'.
 * Precondition: 'id' is a valid ID in 'heap'
 *               'heap' is non-empty
 */
int indexOf(MinHeap* heap, int id){
	return heap->indexMap[id];
}

/* Returns the index of the parent of a node at index 'nodeIndex' in minheap
 * 'heap', if such exists.  Returns NOTHING if there is no such parent.
 */
int parentIdx(MinHeap* heap, int nodeIndex){
	int possibleParent = NOTHING;
	if((isValidIndex(heap, nodeIndex)) && (nodeIndex > ROOT_INDEX)){
		possibleParent = (int) (nodeIndex/2.0);
	}
	return possibleParent;
}

/* Returns the index of the left child of a node at index 'nodeIndex' in
 * minheap 'heap', if such exists.  Returns NOTHING if there is no such left
 * child.
 */
int leftIdx(MinHeap* heap, int nodeIndex){
	int possibleLChild = NOTHING;
	if((isValidIndex(heap, nodeIndex)) && isValidIndex(heap, (nodeIndex*2))){
		possibleLChild = nodeIndex*2;
	}
	return possibleLChild;
}

/* Returns the index of the right child of a node at index 'nodeIndex' in
 * minheap 'heap', if such exists.  Returns NOTHING if there is no such right
 * child.
 */
int rightIdx(MinHeap* heap, int nodeIndex){
	int possibleRChild = NOTHING;
	if((isValidIndex(heap, nodeIndex)) && isValidIndex(heap, (nodeIndex*2+1))){
		possibleRChild = nodeIndex*2+1;
	}
	return possibleRChild;
}

/* Swaps contents of heap->arr[index1] and heap->arr[index2] if both 'index1'
 * and 'index2' are valid indices for minheap 'heap'. Has no effect otherwise.
 */
void swap(MinHeap* heap, int index1, int index2){
	if((isValidIndex(heap, index1)) && (isValidIndex(heap, index2)) &&
		(index1 != index2)){
		heap->indexMap[heap->arr[index1].id] = index2;
		heap->indexMap[heap->arr[index2].id] = index1;
		HeapNode temp = heap->arr[index1];
		heap->arr[index1] = heap->arr[index2];
		heap->arr[index2] = temp;
	}
	return;
}

/* Bubbles up the element newly inserted into minheap 'heap' at index
 * 'nodeIndex', if 'nodeIndex' is a valid index for heap. Has no effect otherwise.
 */
void bubbleUp(MinHeap* heap, int nodeIndex){
	int newIndex = parentIdx(heap, nodeIndex);
	if((isValidIndex(heap, nodeIndex)) && (newIndex != NOTHING)){
		if (priorityAt(heap, nodeIndex) < priorityAt(heap, newIndex)){
			swap(heap, newIndex, nodeIndex);
			bubbleUp(heap, newIndex);
		}
	}
	return;
}

/* Bubbles down the element newly inserted into minheap 'heap' at the root,
 * if it exists. Has no effect otherwise.
 */
void bubbleDown(MinHeap* heap){
	if(heap != NULL){
		int i = ROOT_INDEX;
		int leftI = leftIdx(heap, i);
		int rightI = rightIdx(heap, i);
		while((leftI != NOTHING) || (rightI != NOTHING)){
			if((priorityAt(heap, i) > priorityAt(heap, leftI)) || 
				(priorityAt(heap, i) > priorityAt(heap, rightI))){
				if(priorityAt(heap, leftI) <= priorityAt(heap, rightI)){
					swap(heap, leftI, i);
					i = leftI;
				}
				else{
					swap(heap, rightI, i);
					i = rightI;
				}
				leftI = leftIdx(heap, i);
				rightI = rightIdx(heap, i);
			}
			else{
				return;
			}
		}
	}
	return;
}



/*********************************************************************
 * Required functions
 ********************************************************************/

/* Returns the node with minimum priority in minheap 'heap'.
 * Precondition: heap is non-empty
 */
HeapNode getMin(MinHeap* heap){
	return heap->arr[ROOT_INDEX];
}

/* Removes and returns the node with minimum priority in minheap 'heap'.
 * Precondition: heap is non-empty
 */
HeapNode extractMin(MinHeap* heap){
	HeapNode extracted = getMin(heap);
	swap(heap, ROOT_INDEX, heap->size);
	heap->indexMap[idAt(heap, heap->size)] = NOTHING;
	heap->size--;
	bubbleDown(heap);
	return extracted;
}

/* Inserts a new node with priority 'priority' and ID 'id' into minheap 'heap'.
 * Precondition: 'id' is unique within this minheap
 *               0 <= 'id' < heap->capacity
 *               heap->size < heap->capacity
 */
void insert(MinHeap* heap, int priority, int id){
	if(heap != NULL){
		int newSize = (heap->size+1);
		heap->size = newSize;
		HeapNode *newNode = malloc(sizeof(HeapNode));
		newNode->priority = priority;
		newNode->id = id;
		heap->arr[newSize] = *newNode;
		heap->indexMap[id] = newSize;
		bubbleUp(heap, newSize);
		free(newNode);
	}
	return;
}

/* Returns priority of the node with ID 'id' in 'heap'.
 * Precondition: 'id' is a valid node ID in 'heap'.
 */
int getPriority(MinHeap* heap, int id){
	return priorityAt(heap, id);
}

/* Sets priority of node with ID 'id' in minheap 'heap' to 'newPriority', if
 * such a node exists in 'heap' and its priority is larger than
 * 'newPriority', and returns true. Has no effect and returns false, otherwise.
 * Note: this function bubbles up the node until the heap property is restored.
 */
bool decreasePriority(MinHeap* heap, int id, int newPriority){
	if((heap != NULL) && (id <= heap->capacity)){
		int i = heap->indexMap[id];
		if(priorityAt(heap, i) > newPriority){
			heap->arr[i].priority = newPriority;
			bubbleUp(heap, i);
			return true;
		}
	}
	return false;
}

/* Returns a newly created empty minheap with initial capacity 'capacity'.
 * Precondition: capacity >= 0
 */
MinHeap* newHeap(int capacity){
	// If capacity is 0, then the minheap is null, and that is returned
	if(capacity > 0){
		MinHeap *new = malloc(sizeof(MinHeap));
		new->size = 0;
		new->capacity = capacity;
		new->arr = (HeapNode *)malloc(sizeof(HeapNode)*(capacity+ROOT_INDEX));
		new->indexMap = (int *)malloc(sizeof(int)*(capacity));
		if((new == NULL) || (new->arr == NULL) || (new->indexMap == NULL)){
			printf("Failed allocation creating heap.");
		}
		for(int i = 0; i < capacity; i++){
			new->indexMap[i] = NOTHING;
		}
		return new;
	}
	return NULL;
}

/* Frees all memory allocated for minheap 'heap'.
 */
void deleteHeap(MinHeap* heap){
	free(heap->arr);
	free(heap->indexMap);
	free(heap);
}



/*********************************************************************
 ** Helper functions provided in the starter code
 *********************************************************************/
void printHeap(MinHeap* heap) {
  printf("MinHip with size: %d\n\tcapacity: %d\n\n", heap->size,
         heap->capacity);
  printf("index: priority [ID]\t ID: index\n");
  for (int i = 0; i < heap->capacity; i++)
    printf("%d: %d [%d]\t\t%d: %d\n", i, priorityAt(heap, i), idAt(heap, i), i,
           indexOf(heap, i));
  printf("%d: %d [%d]\t\t\n", heap->capacity, priorityAt(heap, heap->capacity),
         idAt(heap, heap->capacity));
  printf("\n\n");
}
