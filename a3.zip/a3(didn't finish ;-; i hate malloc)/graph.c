/*
 * Our graph implementation.
 *
 * Author: A. Tafliovich.
 * Author (implementation): R. Chen (Student number: 1008163719).
 */

#include "graph.h"

/*********************************************************************
 ** Required functions
 *********************************************************************/

/* Returns a newly created Edge from vertex with ID 'fromVertex' to vertex
 * with ID 'toVertex', with weight 'weight'.
 */
Edge* newEdge(int fromVertex, int toVertex, int weight){
	Edge *e = (Edge *) malloc(sizeof(Edge));
	e->fromVertex = fromVertex;
	e->toVertex = toVertex;
	e->weight = weight;
	return e;
}

/* Returns a newly created AdjList containing 'edge' and pointing to the next
 * AdjList node 'next'.
 */
AdjList* newAdjList(Edge* edge, AdjList* next){
	AdjList *a = malloc(sizeof(AdjList));
	a->edge = edge;
	a->next = next;
	return a;
}

/* Returns a newly created Graph with space for 'numVertices' vertices.
 * Precondition: numVertices >= 0
 */
Graph* newGraph(int numVertices){
	Graph *g = malloc(sizeof(Graph));
	g->numVertices = numVertices;
	g->numEdges = 0;
	g->vertices = (Vertex*) malloc(sizeof(Vertex)*numVertices);
	return g;
}

/* Frees memory allocated for AdjList starting at 'head'.
 */
void deleteAdjList(AdjList* head){
	AdjList *temp = head;
	while(temp != NULL){
		free(temp->edge);
		temp = temp->next;
	}
	free(head);
	return;
}

/* Frees memory allocated for 'vertex''s adjacency list.
 */
void deleteVertex(Vertex* vertex){
	deleteAdjList(vertex->adjList);
	return;
}

/* Frees memory allocated for 'graph'.
 */
void deleteGraph(Graph* graph){
	for(int i = 0; i < graph->numVertices; i++){
		deleteVertex(&graph->vertices[i]);
		//free(graph->vertices[i].value);  //possible delete
	}
	free(graph->vertices);
	free(graph);
}

/*********************************************************************
 ** Helper function provided in the starter code
 *********************************************************************/

void printEdge(Edge* edge) {
  if (edge == NULL) return;
  printf("(%d -- %d, %d)", edge->fromVertex, edge->toVertex, edge->weight);
}

void printAdjList(AdjList* head) {
  while (head != NULL) {
    printEdge(head->edge);
    printf("  ");
    head = head->next;
  }
}

void printVertex(Vertex* vertex) {
  if (vertex == NULL) return;
  printf("%d: ", vertex->id);
  printAdjList(vertex->adjList);
}

void printGraph(Graph* graph) {
  if (graph == NULL) return;

  printf("Number of vertices: %d. Number of edges: %d.\n\n", graph->numVertices,
         graph->numEdges);

  for (int i = 0; i < graph->numVertices; i++) {
    printVertex(&graph->vertices[i]);
    printf("\n");
  }
  printf("\n");
}
