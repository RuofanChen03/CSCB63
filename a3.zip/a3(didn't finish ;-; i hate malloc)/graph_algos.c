/*
 * Graph algorithms.
 *
 * Author: A. Tafliovich.
 */

#include <limits.h>

#include "graph.h"
#include "minheap.h"

#define NOTHING -1

typedef struct records {
  int numVertices;    // total number of vertices in the graph
                      // vertex IDs are 0, 1, ..., numVertices-1
  MinHeap* heap;      // priority queue
  bool* finished;     // finished[id] is true iff vertex id is finished
                      //   i.e. no longer in the PQ
  int* predecessors;  // predecessors[id] is the predecessor of vertex id
  Edge* tree;         // keeps edges for the resulting tree
  int numTreeEdges;   // current number of edges in mst
} Records;

/*************************************************************************
 ** Suggested helper functions, to help with your program design
 *************************************************************************/

/* Returns true iff 'heap' is NULL or is empty. */
bool isEmpty(MinHeap* heap){
	if((heap == NULL)||(heap->size == 0)){
		return true;
	}
	return false;
}

/* Creates, populates, and returns a MinHeap to be used by Prim's and
 * Dijkstra's algorightms on Graph 'graph' starting from vertex with ID
 * 'startVertex'.
 * Precondition: 'startVertex' is valid in 'graph'
 */
MinHeap* initHeap(Graph* graph, int startVertex){
	MinHeap *h = newHeap(graph->numVertices);
	insert(h, 0, startVertex);
	for(int i = 0; i < graph->numVertices; i++){
		if(i != startVertex){
			insert(h, INT_MAX, i);
		}
	}
	return h;
}

/* Creates, populates, and returns all records needed to run Prim's and
 * Dijkstra's algorithms on Graph 'graph' starting from vertex with ID
 * 'startVertex'.
 * Precondition: 'startVertex' is valid in 'graph'
 */
Records* initRecords(Graph* graph, int startVertex){
	Records *r = calloc(1, sizeof(Records));
	r->numVertices = graph->numVertices;
	r->heap = initHeap(graph, startVertex);
	r->finished = (bool *) calloc(1, sizeof(bool)*r->numVertices);
	r->predecessors = (int *) calloc(1, sizeof(int)*r->numVertices);
	r->tree = (Edge *) calloc(1, sizeof(Edge)*(r->numVertices-1));
	r->numTreeEdges = 0;
	for(int i = 0; i < r->numVertices; i++){
		r->finished[i] = false;
		r->predecessors[i] = NOTHING;
	}
	return r;
}

/* Add a new edge to records at index ind. */
void addTreeEdge(Records* records, int ind, int fromVertex, int toVertex,
                 int weight){
	records->tree[ind].fromVertex = fromVertex;
	records->tree[ind].toVertex = toVertex;
	records->tree[ind].weight = weight;
	records->numTreeEdges++;
	return;
}

/*************************************************************************
 ** Required functions.
 *************************************************************************/


/* Runs Prim's algorithm on Graph 'graph' starting from vertex with ID
 * 'startVertex', and return the resulting MST: an array of Edges.
 * Returns NULL if 'startVertex' is not valid in 'graph'.
 * Precondition: 'graph' is connected.
 */
Edge* primGetMST(Graph* graph, int startVertex){
	if((startVertex < 0)||(startVertex >= graph->numVertices)){
		return NULL;
	}
	Records *r = initRecords(graph, startVertex);
	HeapNode u;
	AdjList *temp;
	int tempId;
	while(!(isEmpty(r->heap))){
		u = extractMin(r->heap);
		r->finished[u.id] = true;
		if(u.id != startVertex){
		    addTreeEdge(r, r->numTreeEdges, u.id, r->predecessors[u.id], u.priority);
		}
		temp = graph->vertices[u.id].adjList;
		while(temp != NULL){
		    if(!(r->finished[temp->edge->toVertex])){
    		    if(temp->edge->fromVertex == u.id){
    				tempId = temp->edge->toVertex;
    			}
    			else{
    				tempId = temp->edge->fromVertex;
    			}
    			if(decreasePriority(r->heap, tempId, temp->edge->weight)){
    				r->predecessors[tempId] = u.id;
    			}
    			
		    }
			temp = temp->next;
		}
	}
	free(r->finished);
	deleteHeap(r->heap);
	free(r->predecessors);
	return r->tree;
}

/* Runs Dijkstra's algorithm on Graph 'graph' starting from vertex with ID
 * 'startVertex', and return the resulting distance tree: an array of edges.
 * Returns NULL if 'startVertex' is not valid in 'graph'.
 * Precondition: 'graph' is connected.
 */
Edge* getShortestPaths(Graph* graph, int startVertex){
	if((startVertex < 0)||(startVertex >= graph->numVertices)){
		return NULL;
	}
	Records *r = initRecords(graph, startVertex);
	int distRec[graph->numVertices];
	for(int i = 0; i < graph->numVertices; i++){
		if(i == startVertex){
			distRec[i] = 0;
		}
		else{
			distRec[i] = INT_MAX;
		}
	}
	HeapNode u;
	AdjList *temp;
	int tempId, tempDist;

	while(!(isEmpty(r->heap))){
		u = extractMin(r->heap);
		r->finished[u.id] = true;
		if(u.id == startVertex){
		    addTreeEdge(r, u.id, u.id, u.id, u.priority);
		}
		else{
		    addTreeEdge(r, u.id, u.id, r->predecessors[u.id], u.priority);
		}
		temp = graph->vertices[u.id].adjList;
		while(temp != NULL){
		    if(!(r->finished[temp->edge->toVertex])){
    		    if(temp->edge->fromVertex == u.id){
    				tempId = temp->edge->toVertex;
    			}
    			else{
    				tempId = temp->edge->fromVertex;
    			}
    			
    			tempDist = distRec[u.id] + temp->edge->weight;
    			
    			if(tempDist < distRec[tempId]){
    			    distRec[tempId] = tempDist;
    			    decreasePriority(r->heap, tempId, distRec[tempId]);
    				r->predecessors[tempId] = u.id;
    			}
		    }
			temp = temp->next;
		}
	}
	free(r->finished);
	deleteHeap(r->heap);
	free(r->predecessors);
	return r->tree;
}

/* Creates and returns an array 'paths' of shortest paths from every vertex
 * in the graph to vertex 'startVertex', based on the information in the
 * distance tree 'distTree' produced by Dijkstra's algorithm on a graph with
 * 'numVertices' vertices and with the start vertex 'startVertex'.  paths[id]
 * is the array of Edges of the form
 *   [(id -- id_1, w_0), (id_1 -- id_2, w_1), ..., (id_n -- start, w_n)]
 *   where w_0 + w_1 + ... + w_n = distance(id)
 * Returns NULL if 'startVertex' is not valid in 'distTree'.
 */
AdjList* getPaths(Edge* distTree, int numVertices, int startVertex){
    if((startVertex < 0)||(startVertex >= numVertices)){
		return NULL;
	}
	AdjList *f = malloc(1);
    for(int i = 0; i < numVertices; i++){
        Edge *e = &distTree[i];
        f[e->fromVertex].edge = e;
        f[e->fromVertex].next = &f[e->toVertex];
    }
    f[startVertex].edge = NULL;
    f[startVertex].next = NULL;
    
    return f;
}

/*************************************************************************
 ** Provided helper functions -- part of starter code to help you debug!
 *************************************************************************/
void printRecords(Records* records) {
  if (records == NULL) return;

  int numVertices = records->numVertices;
  printf("Reporting on algorithm's records on %d vertices...\n", numVertices);

  printf("The PQ is:\n");
  printHeap(records->heap);

  printf("The finished array is:\n");
  for (int i = 0; i < numVertices; i++)
    printf("\t%d: %d\n", i, records->finished[i]);

  printf("The predecessors array is:\n");
  for (int i = 0; i < numVertices; i++)
    printf("\t%d: %d\n", i, records->predecessors[i]);

  printf("The TREE edges are:\n");
  for (int i = 0; i < records->numTreeEdges; i++) printEdge(&records->tree[i]);

  printf("... done.\n");
}
